#
# TABLE STRUCTURE FOR: bahanbaku
#

DROP TABLE IF EXISTS `bahanbaku`;

CREATE TABLE `bahanbaku` (
  `id_bahanbaku` int(50) NOT NULL AUTO_INCREMENT,
  `nama_bahanbaku` varchar(255) NOT NULL,
  PRIMARY KEY (`id_bahanbaku`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('30', 'Botol');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('31', 'Tutup Botol Abu-Abu');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('32', 'Cover Cap Ungu');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('33', 'Seal');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('34', 'Stiker');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('35', 'Kardus');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('36', 'Plastik');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('37', 'Lakban');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('47', 'zzzz2');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('48', 'zz3');


#
# TABLE STRUCTURE FOR: detail_hasilproduksi
#

DROP TABLE IF EXISTS `detail_hasilproduksi`;

CREATE TABLE `detail_hasilproduksi` (
  `id_detailhasilproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `id_hasilproduksi` int(255) NOT NULL,
  `tanggal_stockproduksi` date NOT NULL,
  `stock_produksi` int(255) NOT NULL,
  `produksi_reject` int(50) NOT NULL,
  PRIMARY KEY (`id_detailhasilproduksi`),
  KEY `id_produksi_idxfk` (`id_hasilproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `detail_hasilproduksi` (`id_detailhasilproduksi`, `id_hasilproduksi`, `tanggal_stockproduksi`, `stock_produksi`, `produksi_reject`) VALUES ('9', '99', '2022-07-01', '17656', '0');


#
# TABLE STRUCTURE FOR: detail_hasilproduksibulanan
#

DROP TABLE IF EXISTS `detail_hasilproduksibulanan`;

CREATE TABLE `detail_hasilproduksibulanan` (
  `id_totalproduksibulanan` int(10) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `total_produksibulanan` int(20) NOT NULL,
  PRIMARY KEY (`id_totalproduksibulanan`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: detail_pengiriman
#

DROP TABLE IF EXISTS `detail_pengiriman`;

CREATE TABLE `detail_pengiriman` (
  `id_detailpengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengiriman` int(50) NOT NULL,
  `id_driver` int(50) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `jeniskendaraan` varchar(255) NOT NULL,
  `tujuan_pengiriman` varchar(255) NOT NULL,
  `no_kendaraan` varchar(255) NOT NULL,
  `status` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  `jumlah_pengiriman` int(255) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `bukti_surat` varchar(50) NOT NULL,
  `tanggal_diterima` date NOT NULL,
  PRIMARY KEY (`id_detailpengiriman`),
  KEY `id_pengiriman_idxfk` (`id_pengiriman`),
  KEY `id_driver_idxfk2` (`id_driver`),
  CONSTRAINT `id_driver_idxfk2` FOREIGN KEY (`id_driver`) REFERENCES `driver` (`id_driver`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `id_pengiriman_idxfk` FOREIGN KEY (`id_pengiriman`) REFERENCES `pengiriman` (`id_pengiriman`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_suplai
#

DROP TABLE IF EXISTS `detail_suplai`;

CREATE TABLE `detail_suplai` (
  `id_detailsuplai` int(50) NOT NULL AUTO_INCREMENT,
  `tanggal_stockgudang` date NOT NULL,
  `id_bahanbaku` int(50) NOT NULL,
  `stock_pabrik` int(255) NOT NULL,
  `barang_pakai` int(50) NOT NULL,
  `data_stockrejetgudang` int(50) NOT NULL,
  `data_stockrejetproduksi` int(50) NOT NULL,
  PRIMARY KEY (`id_detailsuplai`),
  KEY `id_bahanbaku_idxfk` (`id_bahanbaku`),
  CONSTRAINT `detail_suplai_ibfk_1` FOREIGN KEY (`id_bahanbaku`) REFERENCES `bahanbaku` (`id_bahanbaku`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('23', '2022-06-27', '30', '32500', '1663', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('38', '2022-06-27', '34', '14759', '2300', '0', '300');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('40', '2021-07-21', '31', '5475', '0', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('41', '2021-07-21', '37', '2630', '0', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('43', '2021-07-21', '33', '7550', '0', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('45', '2021-07-21', '47', '20000', '0', '1', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('46', '2021-07-21', '48', '1000', '0', '0', '0');


#
# TABLE STRUCTURE FOR: detail_suplaimasuk
#

DROP TABLE IF EXISTS `detail_suplaimasuk`;

CREATE TABLE `detail_suplaimasuk` (
  `id_detailsuplaimasuk` int(11) NOT NULL AUTO_INCREMENT,
  `id_driver` int(50) NOT NULL,
  `vendor` varchar(50) NOT NULL,
  `shift` varchar(50) NOT NULL,
  `id_bahanbaku` int(50) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `barang_rejectgudang` int(50) NOT NULL,
  PRIMARY KEY (`id_detailsuplaimasuk`),
  KEY `id_bahanbaku_detail_suplaimasuk_idxfk` (`id_bahanbaku`),
  KEY `id_driver_detail_suplaimasuk_idxfk` (`id_driver`),
  CONSTRAINT `detail_suplaimasuk_ibfk_1` FOREIGN KEY (`id_driver`) REFERENCES `driver` (`id_driver`),
  CONSTRAINT `detail_suplaimasuk_ibfk_2` FOREIGN KEY (`id_bahanbaku`) REFERENCES `bahanbaku` (`id_bahanbaku`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;

INSERT INTO `detail_suplaimasuk` (`id_detailsuplaimasuk`, `id_driver`, `vendor`, `shift`, `id_bahanbaku`, `tanggal`, `total`, `barang_rejectgudang`) VALUES ('120', '7', 'PT Indofarma', 'shift1', '30', '2022-06-27', '2500', '0');
INSERT INTO `detail_suplaimasuk` (`id_detailsuplaimasuk`, `id_driver`, `vendor`, `shift`, `id_bahanbaku`, `tanggal`, `total`, `barang_rejectgudang`) VALUES ('121', '8', 'PT Lautan Jaya', 'shift2', '34', '2022-06-27', '1500', '0');


#
# TABLE STRUCTURE FOR: detail_transaksi_produksi
#

DROP TABLE IF EXISTS `detail_transaksi_produksi`;

CREATE TABLE `detail_transaksi_produksi` (
  `id_detail_transaksiproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_transaksiproduksi` int(11) NOT NULL,
  `id_detailsuplai` int(50) NOT NULL,
  `jumlah_pengurangan` int(50) NOT NULL,
  `barang_rejectproduksi` int(50) NOT NULL,
  PRIMARY KEY (`id_detail_transaksiproduksi`),
  KEY `id_detail_semuabarang_idxfk` (`id_detailsuplai`),
  KEY `id_detailproduksi_idxfk` (`id_transaksiproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

INSERT INTO `detail_transaksi_produksi` (`id_detail_transaksiproduksi`, `id_transaksiproduksi`, `id_detailsuplai`, `jumlah_pengurangan`, `barang_rejectproduksi`) VALUES ('100', '60', '23', '1000', '20');
INSERT INTO `detail_transaksi_produksi` (`id_detail_transaksiproduksi`, `id_transaksiproduksi`, `id_detailsuplai`, `jumlah_pengurangan`, `barang_rejectproduksi`) VALUES ('101', '60', '38', '1000', '20');
INSERT INTO `detail_transaksi_produksi` (`id_detail_transaksiproduksi`, `id_transaksiproduksi`, `id_detailsuplai`, `jumlah_pengurangan`, `barang_rejectproduksi`) VALUES ('104', '63', '23', '1663', '0');


#
# TABLE STRUCTURE FOR: driver
#

DROP TABLE IF EXISTS `driver`;

CREATE TABLE `driver` (
  `id_driver` int(50) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(50) NOT NULL,
  `shift` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  PRIMARY KEY (`id_driver`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('7', 'Akbar Haris', 'shift1', '087865516211');
INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('8', 'Hanif Jauhari', 'shift1', '08786512234');
INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('9', 'Lutfi Fajar', 'shift3', '081869122450');


#
# TABLE STRUCTURE FOR: hasil_produksi
#

DROP TABLE IF EXISTS `hasil_produksi`;

CREATE TABLE `hasil_produksi` (
  `id_hasilproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `id` int(50) NOT NULL,
  `shift` varchar(255) NOT NULL,
  `jumlah_produksi` int(255) NOT NULL,
  `produksi_gagal` int(50) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_hasilproduksi`),
  KEY `id_pegawai_idxfk` (`id`),
  CONSTRAINT `hasil_produksi_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=latin1;

INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('160', '34', 'shift1', '26700', '0', '2019-01-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('165', '34', 'shift1', '11000', '0', '2019-02-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('166', '34', 'shift1', '15000', '0', '2019-03-001');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('167', '34', 'shift1', '23500', '0', '2019-04-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('168', '34', 'shift1', '35500', '0', '2019-05-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('169', '34', 'shift1', '22200', '0', '2019-06-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('170', '34', 'shift1', '16000', '0', '2019-07-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('171', '34', 'shift1', '20000', '0', '2019-08-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('172', '34', 'shift1', '30100', '0', '2019-09-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('173', '34', 'shift1', '24400', '0', '2019-10-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('174', '34', 'shift1', '15000', '0', '2019-11-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('175', '34', 'shift1', '17100', '0', '2019-12-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('176', '34', 'shift1', '30000', '0', '2020-01-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('177', '34', 'shift1', '21100', '0', '2020-02-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('178', '34', 'shift1', '15000', '0', '2020-03-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('179', '34', 'shift1', '22200', '0', '2020-04-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('180', '34', 'shift1', '35500', '0', '2020-05-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('181', '34', 'shift1', '15000', '0', '2020-06-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('182', '34', 'shift1', '16000', '0', '2020-07-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('183', '34', 'shift1', '20000', '0', '2020-08-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('184', '34', 'shift1', '30100', '0', '2020-09-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('185', '34', 'shift1', '24400', '0', '2020-10-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('186', '34', 'shift1', '14000', '0', '2020-11-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('187', '34', 'shift1', '17000', '0', '2020-12-01');


#
# TABLE STRUCTURE FOR: notifikasi
#

DROP TABLE IF EXISTS `notifikasi`;

CREATE TABLE `notifikasi` (
  `id_notifikasi` int(11) NOT NULL AUTO_INCREMENT,
  `receiver` varchar(100) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `dibuat_pada` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `read_status` enum('delivery','seen') NOT NULL,
  PRIMARY KEY (`id_notifikasi`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4;

INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('1', 'admin', 'Produksi Baru', 'Pengolahan dibagian produksi', '', '2021-06-05 14:45:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('2', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 25', 'http://localhost/ta-inventory-hav/produksiclient', '2021-06-05 16:35:27', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('3', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 12', 'http://localhost/ta-inventory-hav-v1.1.0/produksiclient', '2021-06-05 17:02:17', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('4', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total asd', 'http://localhost/ta-inventory-hav-v1.1.0/produksiclient', '2021-06-05 17:02:17', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('5', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 12', 'http://localhost/ta-inventory-hav-v1.1.0/produksiclient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('6', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 10', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('7', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 100', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('8', 'admin', 'Tambah Barang Baru', 'Telah dibuat produksi baru dengan total 20', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('9', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 20', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('10', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('11', 'admin', 'Tambah Barang Baru', 'Telah dibuat  A baru dengan total 1', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('12', 'admin', 'Tambah Barang Baru', 'Telah dibuat  T baru dengan total 2', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('13', 'admin', 'Tambah Barang Baru', 'Telah dibuat  H baru dengan total 1', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('14', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 100', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('15', 'admin', 'Tambah Produksi Baru', 'Telah data produksi baru dengan total produksi ', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('16', 'admin', 'Tambah Produksi Baru', 'Telah data produksi baru dengan total produksi ', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('17', 'admin', 'Tambah Produksi Baru', 'Telah data produksi baru dengan total produksi ', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('18', 'admin', 'Tambah Barang Baru', 'Telah dibuat  H baru dengan total s', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('19', 'admin', 'Tambah Produksi Baru', 'Telah dibuat  1 baru dengan total z', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('20', 'admin', 'Tambah Produksi Baru', 'Telah dibuat  1 baru dengan total xxxx', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('21', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 1', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('22', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 1', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('23', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Produksi   baru dengan total ', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:57:05', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('24', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  1Oleh Staff Haris123124Shift shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:57:05', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('25', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  10Oleh Staff HarisShift shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('26', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Akbar HarisDengan Nomor Kendaraan N9023AAB', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('27', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver awDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('28', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan N99293NA', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('29', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P929NX', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('30', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver MantapDengan Nomor Kendaraan zxczxczxc', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('31', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan N99293NAProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('32', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Staff Soleh shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('33', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('34', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('35', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Tutup Botol baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('36', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Driver AyasDengan Nomor Kendaraan N999XP', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('37', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Driver Ayas dengan Nomor Kendaraan N999XPProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('38', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  1000Oleh Staff Haris shift2', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('39', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Akbar Haris N shift2', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('40', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Avdio shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('41', 'admin', 'Tambah Barang Baru', 'Telah dibuat  isolasi besar baru dengan total 20', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('42', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Isolasi besar baru dengan total 1000', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('43', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Tutup Botol baru dengan total 500', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('44', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Isolasi besar baru dengan total 200', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('45', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('46', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('47', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver dhioDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('48', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver dhio dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('49', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Manysur shift2', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('50', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:17:35', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('51', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:17:35', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('52', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 300', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:25:47', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('53', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('54', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('55', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('56', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff zaman shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('57', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  SurabayaNama Driver Roy dengan Nomor Kendaraan L98128NProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('58', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver xxxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('59', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver xxxx dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('60', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver xxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('61', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('62', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 110', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('63', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris2e12ewr shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('64', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('65', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Rifaldi shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('66', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  75Oleh Staff Dwi shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('67', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Lukman shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('68', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Bocil shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('69', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 100', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('70', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Isolasi baru dengan total 10', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('71', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Azmat shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('72', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver LALADengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('73', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('74', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('75', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('76', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff zaman12344 shift3', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('77', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Testing1 shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 11:26:47', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('78', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 100', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-27 11:26:47', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('79', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Testing Staff PengirimanDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('80', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('81', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('82', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Testing Staff PengirimanDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('83', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('84', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('85', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('86', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('87', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('88', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('89', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('90', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Staff Produksi shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('91', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Test Gudangg baru dengan total 5000', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('92', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Test Gudangg baru dengan total 5000', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('93', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Testing Staff PengirimanDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('94', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('95', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('96', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Akbarxxxx dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('97', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver x1Dengan Nomor Kendaraan x1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('98', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver x2Dengan Nomor Kendaraan x2', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('99', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver x3Dengan Nomor Kendaraan x3', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('100', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x1Nama Driver x1 dengan Nomor Kendaraan x1Proses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('101', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x2Nama Driver x2 dengan Nomor Kendaraan x2Proses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('102', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x3Nama Driver x3 dengan Nomor Kendaraan x3Proses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('103', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x3Nama Driver x3 dengan Nomor Kendaraan x3Proses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('104', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisxxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('105', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver xxxxxxxxxxxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('106', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Harisxxx dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('107', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver xxxxxxxxxxxx dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('108', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 3Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('109', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 4Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('110', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('111', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('112', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 4Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('113', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('114', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('115', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('116', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('117', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('118', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('119', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:59:09', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('120', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 1000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('121', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  1000Oleh Staff  shift2', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('122', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff  shift2', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('123', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('124', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 2000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('125', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 1000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('126', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 2000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('127', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  3000Oleh Staff  shift1', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('128', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  906Oleh Staff  shift1', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('129', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 1000', 'http://localhost:8080/FinalTArev/BarangClient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('130', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 10000', 'http://localhost:8080/FinalTArev/BarangClient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('131', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 3Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('132', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 4Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('133', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2022-06-26 18:05:26', 'seen');


#
# TABLE STRUCTURE FOR: pegawai
#

DROP TABLE IF EXISTS `pegawai`;

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `kode_unik` varchar(10) NOT NULL,
  `level` enum('admin','Staff Produksi','Staff Pengiriman','Staff Gudang') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('32', 'Staf Gudang Perusahaan', 'gudang', '123', 'VV4HMZ', 'Staff Gudang');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('34', 'Admin Perusahaan', 'Admin', 'admin123', 'JVC4CE', 'admin');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('35', 'Staf Produksi Perusahaan', 'Produksi', '1234', 'AJHHNE', 'Staff Produksi');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('36', 'Staf Pengiriman Perusahaan', 'pengiriman', '1234', 'IOEJ3X', 'Staff Pengiriman');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('38', 'Avdio Bayu', 'Avdio', '1234', 'N4SVHV', 'Staff Produksi');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('41', 'haris 1', '1234', '1234', 'M8RH20', 'Staff Produksi');


#
# TABLE STRUCTURE FOR: pengiriman
#

DROP TABLE IF EXISTS `pengiriman`;

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(255) NOT NULL AUTO_INCREMENT,
  `id_driver` int(50) NOT NULL,
  `nomorhp` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `jenis_kendaraan` varchar(255) NOT NULL,
  `nomor_kendaraan` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti_surat` varchar(50) NOT NULL,
  `status_pengiriman` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  PRIMARY KEY (`id_pengiriman`),
  KEY `id_driver_idxfk` (`id_driver`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;

INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('109', '3', '0256123', 'Malang', '23', 'Pickup', 'P2032XM', '2021-07-15', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('114', '3', '0256123', 'Malang', '1000', 'Pickup', 'P2032XM', '2021-07-22', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('115', '4', '0256123', 'Malang', '2000', 'Pickup', 'P2032XM', '2021-07-22', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('116', '3', '0256123', 'Malang', '23', 'Pickup', 'P2032XM', '2021-07-22', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('117', '4', '0256123', 'Malang', '23', 'Pickup', 'P2032XM', '2021-07-24', '1626856967.png', 'Proses Pengiriman');


#
# TABLE STRUCTURE FOR: peramalan
#

DROP TABLE IF EXISTS `peramalan`;

CREATE TABLE `peramalan` (
  `id_peramalan` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL COMMENT 'relasi dengan id pada tabel pegawai',
  `tanggal_awal` varchar(15) NOT NULL,
  `tanggal_akhir` varchar(15) NOT NULL,
  `jenis_pemulusan` enum('keseluruhan','sebagian') NOT NULL,
  `nilai_pemulusan` float DEFAULT NULL,
  `perhitungan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `pengujian` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`pengujian`)),
  `tanggal_peramalan` timestamp NOT NULL DEFAULT current_timestamp(),
  `status_pengajuan` enum('pengajuan','diterima','ditolak') NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_peramalan`),
  KEY `id_pegawai` (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `peramalan` (`id_peramalan`, `id_pegawai`, `tanggal_awal`, `tanggal_akhir`, `jenis_pemulusan`, `nilai_pemulusan`, `perhitungan`, `pengujian`, `tanggal_peramalan`, `status_pengajuan`, `keterangan`) VALUES ('1', '35', '1546275600', '1606755600', 'sebagian', '0.1', '[\n    [\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"January\",\n            \"actual\": \"267\",\n            \"pemulusan_1\": \"267\",\n            \"pemulusan_2\": \"267\",\n            \"pemulusan_3\": \"267\",\n            \"at\": 0,\n            \"bt\": 0,\n            \"ct\": 0,\n            \"Ft\": 0\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"February\",\n            \"actual\": \"110\",\n            \"pemulusan_1\": 251.3,\n            \"pemulusan_2\": 265.43,\n            \"pemulusan_3\": 266.843,\n            \"at\": 224.45300000000015,\n            \"bt\": -0.44744999999999646,\n            \"ct\": -0.15699999999999983,\n            \"Ft\": 0\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"March\",\n            \"actual\": \"150\",\n            \"pemulusan_1\": 241.17000000000002,\n            \"pemulusan_2\": 263.004,\n            \"pemulusan_3\": 266.45910000000003,\n            \"at\": 200.95709999999997,\n            \"bt\": -0.6623649999999967,\n            \"ct\": -0.22689999999999985,\n            \"Ft\": 223.92705000000015\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"April\",\n            \"actual\": \"235\",\n            \"pemulusan_1\": 240.55300000000003,\n            \"pemulusan_2\": 260.75890000000004,\n            \"pemulusan_3\": 265.88908000000004,\n            \"at\": 205.27138000000002,\n            \"bt\": -0.5688320000000003,\n            \"ct\": -0.1861200000000006,\n            \"Ft\": 200.18128499999997\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"May\",\n            \"actual\": \"355\",\n            \"pemulusan_1\": 251.99770000000004,\n            \"pemulusan_2\": 259.8827800000001,\n            \"pemulusan_3\": 265.28845,\n            \"at\": 241.63320999999996,\n            \"bt\": -0.1442405000000025,\n            \"ct\": -0.030610000000001775,\n            \"Ft\": 204.60948800000003\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"June\",\n            \"actual\": \"222\",\n            \"pemulusan_1\": 248.99793000000005,\n            \"pemulusan_2\": 258.7942950000001,\n            \"pemulusan_3\": 264.63903450000004,\n            \"at\": 235.24993950000004,\n            \"bt\": -0.19910167500000012,\n            \"ct\": -0.04878550000000113,\n            \"Ft\": 241.47366449999996\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"July\",\n            \"actual\": \"160\",\n            \"pemulusan_1\": 240.09813700000007,\n            \"pemulusan_2\": 256.92467920000007,\n            \"pemulusan_3\": 263.86759897,\n            \"at\": 213.38797237000006,\n            \"bt\": -0.41269863549999813,\n            \"ct\": -0.12202003000000075,\n            \"Ft\": 235.02644507500003\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"August\",\n            \"actual\": \"200\",\n            \"pemulusan_1\": 236.08832330000007,\n            \"pemulusan_2\": 254.84104361000007,\n            \"pemulusan_3\": 262.964943434,\n            \"at\": 206.706782504,\n            \"bt\": -0.45112057009999934,\n            \"ct\": -0.13122000600000064,\n            \"Ft\": 212.91426371950007\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"September\",\n            \"actual\": \"301\",\n            \"pemulusan_1\": 242.57949097000005,\n            \"pemulusan_2\": 253.6148883460001,\n            \"pemulusan_3\": 262.02993792520004,\n            \"at\": 228.92374579719984,\n            \"bt\": -0.18246297607999995,\n            \"ct\": -0.032349972800001285,\n            \"Ft\": 206.1900519309\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"October\",\n            \"actual\": \"244\",\n            \"pemulusan_1\": 242.72154187300006,\n            \"pemulusan_2\": 252.5255536987001,\n            \"pemulusan_3\": 261.07949950255005,\n            \"at\": 231.66746402545,\n            \"bt\": -0.13748435535250056,\n            \"ct\": -0.015432913850000566,\n            \"Ft\": 228.72510783471986\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"November\",\n            \"actual\": \"150\",\n            \"pemulusan_1\": 233.44938768570006,\n            \"pemulusan_2\": 250.6179370974001,\n            \"pemulusan_3\": 260.03334326203503,\n            \"at\": 208.5276950269349,\n            \"bt\": -0.36783962318025243,\n            \"ct\": -0.09571781786500139,\n            \"Ft\": 231.52226321317247\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"December\",\n            \"actual\": \"171\",\n            \"pemulusan_1\": 227.20444891713007,\n            \"pemulusan_2\": 248.2765882793731,\n            \"pemulusan_3\": 258.85766776376886,\n            \"at\": 195.6412496770397,\n            \"bt\": -0.4737455086424213,\n            \"ct\": -0.12951925775120132,\n            \"Ft\": 208.11199649482214\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"January\",\n            \"actual\": \"300\",\n            \"pemulusan_1\": 234.48400402541705,\n            \"pemulusan_2\": 246.8973298539775,\n            \"pemulusan_3\": 257.66163397278973,\n            \"at\": 220.42165648710824,\n            \"bt\": -0.17558868405849973,\n            \"ct\": -0.020358292712941237,\n            \"Ft\": 195.10274453952167\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"February\",\n            \"actual\": \"211\",\n            \"pemulusan_1\": 232.13560362287535,\n            \"pemulusan_2\": 245.42115723086732,\n            \"pemulusan_3\": 256.43758629859747,\n            \"at\": 216.5809254746215,\n            \"bt\": -0.1994429462552722,\n            \"ct\": -0.02801388321310899,\n            \"Ft\": 220.23588865669325\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"March\",\n            \"actual\": \"150\",\n            \"pemulusan_1\": 223.92204326058783,\n            \"pemulusan_2\": 243.27124583383937,\n            \"pemulusan_3\": 255.12095225212167,\n            \"at\": 197.07334453236714,\n            \"bt\": -0.38627592842739966,\n            \"ct\": -0.092586372283571,\n            \"Ft\": 216.36747558675967\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"April\",\n            \"actual\": \"222\",\n            \"pemulusan_1\": 223.72983893452903,\n            \"pemulusan_2\": 241.31710514390835,\n            \"pemulusan_3\": 253.74056754130035,\n            \"at\": 200.97876891316238,\n            \"bt\": -0.31335279803232025,\n            \"ct\": -0.0637506643455225,\n            \"Ft\": 196.64077541779795\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"May\",\n            \"actual\": \"355\",\n            \"pemulusan_1\": 236.85685504107613,\n            \"pemulusan_2\": 240.87108013362516,\n            \"pemulusan_3\": 252.45361880053284,\n            \"at\": 240.41094352288567,\n            \"bt\": 0.12825404357122944,\n            \"ct\": 0.09343597005381056,\n            \"Ft\": 200.63354078295728\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"June\",\n            \"actual\": \"150\",\n            \"pemulusan_1\": 228.17116953696853,\n            \"pemulusan_2\": 239.60108907395949,\n            \"pemulusan_3\": 251.1683658278755,\n            \"at\": 216.87860721690254,\n            \"bt\": -0.12386193496271894,\n            \"ct\": 0.0016957681101860231,\n            \"Ft\": 240.5859155514838\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"July\",\n            \"actual\": \"160\",\n            \"pemulusan_1\": 221.35405258327168,\n            \"pemulusan_2\": 237.7763854248907,\n            \"pemulusan_3\": 249.82916778757703,\n            \"at\": 200.56216926271998,\n            \"bt\": -0.2822687400429926,\n            \"ct\": -0.05394506764114403,\n            \"Ft\": 216.75559316599492\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"August\",\n            \"actual\": \"200\",\n            \"pemulusan_1\": 219.21864732494453,\n            \"pemulusan_2\": 235.92061161489607,\n            \"pemulusan_3\": 248.43831217030896,\n            \"at\": 198.33241930045432,\n            \"bt\": -0.2811438983932445,\n            \"ct\": -0.0516575769696131,\n            \"Ft\": 200.2529279888564\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"September\",\n            \"actual\": \"301\",\n            \"pemulusan_1\": 227.39678259245008,\n            \"pemulusan_2\": 235.0682287126515,\n            \"pemulusan_3\": 247.1013038245432,\n            \"at\": 224.08696546393895,\n            \"bt\": 0.014379162054887203,\n            \"ct\": 0.05384727150234951,\n            \"Ft\": 198.02544661357626\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"October\",\n            \"actual\": \"244\",\n            \"pemulusan_1\": 229.05710433320507,\n            \"pemulusan_2\": 234.46711627470685,\n            \"pemulusan_3\": 245.83788506955958,\n            \"at\": 229.60784924505427,\n            \"bt\": 0.07602949915244216,\n            \"ct\": 0.07358959078211043,\n            \"Ft\": 224.12826826174503\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"November\",\n            \"actual\": \"140\",\n            \"pemulusan_1\": 220.15139389988457,\n            \"pemulusan_2\": 233.03554403722464,\n            \"pemulusan_3\": 244.5576509663261,\n            \"at\": 205.90520055430585,\n            \"bt\": -0.17426561801046095,\n            \"ct\": -0.016815348249859474,\n            \"Ft\": 229.72067353959775\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"December\",\n            \"actual\": \"170\",\n            \"pemulusan_1\": 215.1362545098961,\n            \"pemulusan_2\": 231.2456150844918,\n            \"pemulusan_3\": 243.22644737814267,\n            \"at\": 194.89836565435553,\n            \"bt\": -0.2732864424306663,\n            \"ct\": -0.05096948494993588,\n            \"Ft\": 205.72252726217047\n        },\n        {\n            \"tahun\": \"2021\",\n            \"bulan\": \"January\",\n            \"num_bulan\": \"01\",\n            \"actual\": \"\",\n            \"pemulusan_1\": \"\",\n            \"pemulusan_2\": \"\",\n            \"pemulusan_3\": \"\",\n            \"at\": \"\",\n            \"bt\": \"\",\n            \"ct\": \"\",\n            \"Ft\": 194.5995944694499\n        }\n    ]\n]', '[\n    [\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"January\",\n            \"actual\": \"267\",\n            \"Ft\": 0,\n            \"PE\": \"-\",\n            \"APE\": \"-\"\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"February\",\n            \"actual\": \"110\",\n            \"Ft\": 0,\n            \"PE\": \"-\",\n            \"APE\": \"-\"\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"March\",\n            \"actual\": \"150\",\n            \"Ft\": 223.92705000000015,\n            \"PE\": -49.2847000000001,\n            \"APE\": 49.2847000000001\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"April\",\n            \"actual\": \"235\",\n            \"Ft\": 200.18128499999997,\n            \"PE\": 14.816474468085117,\n            \"APE\": 14.816474468085117\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"May\",\n            \"actual\": \"355\",\n            \"Ft\": 204.60948800000003,\n            \"PE\": 42.36352450704224,\n            \"APE\": 42.36352450704224\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"June\",\n            \"actual\": \"222\",\n            \"Ft\": 241.47366449999996,\n            \"PE\": -8.771920945945926,\n            \"APE\": 8.771920945945926\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"July\",\n            \"actual\": \"160\",\n            \"Ft\": 235.02644507500003,\n            \"PE\": -46.89152817187502,\n            \"APE\": 46.89152817187502\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"August\",\n            \"actual\": \"200\",\n            \"Ft\": 212.91426371950007,\n            \"PE\": -6.457131859750036,\n            \"APE\": 6.457131859750036\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"September\",\n            \"actual\": \"301\",\n            \"Ft\": 206.1900519309,\n            \"PE\": 31.49832161764119,\n            \"APE\": 31.49832161764119\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"October\",\n            \"actual\": \"244\",\n            \"Ft\": 228.72510783471986,\n            \"PE\": 6.2602017070820235,\n            \"APE\": 6.2602017070820235\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"November\",\n            \"actual\": \"150\",\n            \"Ft\": 231.52226321317247,\n            \"PE\": -54.348175475448315,\n            \"APE\": 54.348175475448315\n        },\n        {\n            \"tahun\": \"2019\",\n            \"bulan\": \"December\",\n            \"actual\": \"171\",\n            \"Ft\": 208.11199649482214,\n            \"PE\": -21.70292192679657,\n            \"APE\": 21.70292192679657\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"January\",\n            \"actual\": \"300\",\n            \"Ft\": 195.10274453952167,\n            \"PE\": 34.96575182015945,\n            \"APE\": 34.96575182015945\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"February\",\n            \"actual\": \"211\",\n            \"Ft\": 220.23588865669325,\n            \"PE\": -4.377198415494431,\n            \"APE\": 4.377198415494431\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"March\",\n            \"actual\": \"150\",\n            \"Ft\": 216.36747558675967,\n            \"PE\": -44.24498372450644,\n            \"APE\": 44.24498372450644\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"April\",\n            \"actual\": \"222\",\n            \"Ft\": 196.64077541779795,\n            \"PE\": 11.423074136127049,\n            \"APE\": 11.423074136127049\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"May\",\n            \"actual\": \"355\",\n            \"Ft\": 200.63354078295728,\n            \"PE\": 43.483509638603586,\n            \"APE\": 43.483509638603586\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"June\",\n            \"actual\": \"150\",\n            \"Ft\": 240.5859155514838,\n            \"PE\": -60.39061036765586,\n            \"APE\": 60.39061036765586\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"July\",\n            \"actual\": \"160\",\n            \"Ft\": 216.75559316599492,\n            \"PE\": -35.47224572874683,\n            \"APE\": 35.47224572874683\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"August\",\n            \"actual\": \"200\",\n            \"Ft\": 200.2529279888564,\n            \"PE\": -0.12646399442820666,\n            \"APE\": 0.12646399442820666\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"September\",\n            \"actual\": \"301\",\n            \"Ft\": 198.02544661357626,\n            \"PE\": 34.21081507854609,\n            \"APE\": 34.21081507854609\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"October\",\n            \"actual\": \"244\",\n            \"Ft\": 224.12826826174503,\n            \"PE\": 8.144152351743838,\n            \"APE\": 8.144152351743838\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"November\",\n            \"actual\": \"140\",\n            \"Ft\": 229.72067353959775,\n            \"PE\": -64.08619538542698,\n            \"APE\": 64.08619538542698\n        },\n        {\n            \"tahun\": \"2020\",\n            \"bulan\": \"December\",\n            \"actual\": \"170\",\n            \"Ft\": 205.72252726217047,\n            \"PE\": -21.013251330688515,\n            \"APE\": 21.013251330688515\n        },\n        {\n            \"tahun\": \"2021\",\n            \"bulan\": \"January\",\n            \"actual\": \"\",\n            \"Ft\": 194.5995944694499,\n            \"PE\": \"-\",\n            \"APE\": \"-\"\n        }\n    ]\n]', '2022-07-06 20:02:21', 'pengajuan', '');


#
# TABLE STRUCTURE FOR: transaksi_produksi
#

DROP TABLE IF EXISTS `transaksi_produksi`;

CREATE TABLE `transaksi_produksi` (
  `id_transaksiproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_hasilproduksi` int(50) NOT NULL,
  `id` int(50) NOT NULL,
  `tanggal` date NOT NULL,
  `shift` varchar(50) NOT NULL,
  PRIMARY KEY (`id_transaksiproduksi`),
  KEY `id_produk_idxfk` (`id_hasilproduksi`),
  KEY `id_pegawai_idxfk2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

INSERT INTO `transaksi_produksi` (`id_transaksiproduksi`, `id_hasilproduksi`, `id`, `tanggal`, `shift`) VALUES ('63', '129', '41', '2022-01-01', 'shift1');
INSERT INTO `transaksi_produksi` (`id_transaksiproduksi`, `id_hasilproduksi`, `id`, `tanggal`, `shift`) VALUES ('64', '158', '32', '2022-06-27', 'shift1');


