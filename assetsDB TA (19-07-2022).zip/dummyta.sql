#
# TABLE STRUCTURE FOR: bahanbaku
#

DROP TABLE IF EXISTS `bahanbaku`;

CREATE TABLE `bahanbaku` (
  `id_bahanbaku` int(50) NOT NULL AUTO_INCREMENT,
  `nama_bahanbaku` varchar(255) NOT NULL,
  PRIMARY KEY (`id_bahanbaku`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('30', 'Botol');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('31', 'Tutup Botol Abu-Abu');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('32', 'Cover Cap Ungu');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('33', 'Seal');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('34', 'Stiker');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('35', 'Kardus');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('36', 'Plastik');
INSERT INTO `bahanbaku` (`id_bahanbaku`, `nama_bahanbaku`) VALUES ('37', 'Lakban');


#
# TABLE STRUCTURE FOR: detail_hasilproduksi
#

DROP TABLE IF EXISTS `detail_hasilproduksi`;

CREATE TABLE `detail_hasilproduksi` (
  `id_detailhasilproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `id_hasilproduksi` int(255) NOT NULL,
  `tanggal_stockproduksi` date NOT NULL,
  `stock_produksi` int(255) NOT NULL,
  `produksi_reject` int(50) NOT NULL,
  PRIMARY KEY (`id_detailhasilproduksi`),
  KEY `id_produksi_idxfk` (`id_hasilproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `detail_hasilproduksi` (`id_detailhasilproduksi`, `id_hasilproduksi`, `tanggal_stockproduksi`, `stock_produksi`, `produksi_reject`) VALUES ('9', '99', '2022-07-18', '1416579', '0');


#
# TABLE STRUCTURE FOR: detail_hasilproduksibulanan
#

DROP TABLE IF EXISTS `detail_hasilproduksibulanan`;

CREATE TABLE `detail_hasilproduksibulanan` (
  `id_totalproduksibulanan` int(10) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `total_produksibulanan` int(20) NOT NULL,
  PRIMARY KEY (`id_totalproduksibulanan`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: detail_pengiriman
#

DROP TABLE IF EXISTS `detail_pengiriman`;

CREATE TABLE `detail_pengiriman` (
  `id_detailpengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengiriman` int(50) NOT NULL,
  `id_driver` int(50) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `jeniskendaraan` varchar(255) NOT NULL,
  `tujuan_pengiriman` varchar(255) NOT NULL,
  `no_kendaraan` varchar(255) NOT NULL,
  `status` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  `jumlah_pengiriman` int(255) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `bukti_surat` varchar(50) NOT NULL,
  `tanggal_diterima` date NOT NULL,
  PRIMARY KEY (`id_detailpengiriman`),
  KEY `id_pengiriman_idxfk` (`id_pengiriman`),
  KEY `id_driver_idxfk2` (`id_driver`),
  CONSTRAINT `id_driver_idxfk2` FOREIGN KEY (`id_driver`) REFERENCES `driver` (`id_driver`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `id_pengiriman_idxfk` FOREIGN KEY (`id_pengiriman`) REFERENCES `pengiriman` (`id_pengiriman`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_suplai
#

DROP TABLE IF EXISTS `detail_suplai`;

CREATE TABLE `detail_suplai` (
  `id_detailsuplai` int(50) NOT NULL AUTO_INCREMENT,
  `tanggal_stockgudang` date NOT NULL,
  `id_bahanbaku` int(50) NOT NULL,
  `stock_pabrik` int(255) NOT NULL,
  `barang_pakai` int(50) NOT NULL,
  `data_stockrejetgudang` int(50) NOT NULL,
  `data_stockrejetproduksi` int(50) NOT NULL,
  PRIMARY KEY (`id_detailsuplai`),
  KEY `id_bahanbaku_idxfk` (`id_bahanbaku`),
  CONSTRAINT `detail_suplai_ibfk_1` FOREIGN KEY (`id_bahanbaku`) REFERENCES `bahanbaku` (`id_bahanbaku`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('23', '2022-06-27', '30', '32500', '1663', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('38', '2022-06-27', '34', '14759', '2300', '0', '300');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('40', '2021-07-21', '31', '5475', '0', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('41', '2021-07-21', '37', '2630', '0', '0', '0');
INSERT INTO `detail_suplai` (`id_detailsuplai`, `tanggal_stockgudang`, `id_bahanbaku`, `stock_pabrik`, `barang_pakai`, `data_stockrejetgudang`, `data_stockrejetproduksi`) VALUES ('43', '2021-07-21', '33', '7550', '0', '0', '0');


#
# TABLE STRUCTURE FOR: detail_suplaimasuk
#

DROP TABLE IF EXISTS `detail_suplaimasuk`;

CREATE TABLE `detail_suplaimasuk` (
  `id_detailsuplaimasuk` int(11) NOT NULL AUTO_INCREMENT,
  `id_driver` int(50) NOT NULL,
  `vendor` varchar(50) NOT NULL,
  `shift` varchar(50) NOT NULL,
  `id_bahanbaku` int(50) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `barang_rejectgudang` int(50) NOT NULL,
  PRIMARY KEY (`id_detailsuplaimasuk`),
  KEY `id_bahanbaku_detail_suplaimasuk_idxfk` (`id_bahanbaku`),
  KEY `id_driver_detail_suplaimasuk_idxfk` (`id_driver`),
  CONSTRAINT `detail_suplaimasuk_ibfk_1` FOREIGN KEY (`id_driver`) REFERENCES `driver` (`id_driver`),
  CONSTRAINT `detail_suplaimasuk_ibfk_2` FOREIGN KEY (`id_bahanbaku`) REFERENCES `bahanbaku` (`id_bahanbaku`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;

INSERT INTO `detail_suplaimasuk` (`id_detailsuplaimasuk`, `id_driver`, `vendor`, `shift`, `id_bahanbaku`, `tanggal`, `total`, `barang_rejectgudang`) VALUES ('120', '7', 'PT Indofarma', 'shift1', '30', '2022-06-27', '2500', '0');
INSERT INTO `detail_suplaimasuk` (`id_detailsuplaimasuk`, `id_driver`, `vendor`, `shift`, `id_bahanbaku`, `tanggal`, `total`, `barang_rejectgudang`) VALUES ('121', '8', 'PT Lautan Jaya', 'shift2', '34', '2022-06-27', '1500', '0');


#
# TABLE STRUCTURE FOR: detail_transaksi_produksi
#

DROP TABLE IF EXISTS `detail_transaksi_produksi`;

CREATE TABLE `detail_transaksi_produksi` (
  `id_detail_transaksiproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_transaksiproduksi` int(11) NOT NULL,
  `id_detailsuplai` int(50) NOT NULL,
  `jumlah_pengurangan` int(50) NOT NULL,
  `barang_rejectproduksi` int(50) NOT NULL,
  PRIMARY KEY (`id_detail_transaksiproduksi`),
  KEY `id_detail_semuabarang_idxfk` (`id_detailsuplai`),
  KEY `id_detailproduksi_idxfk` (`id_transaksiproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

INSERT INTO `detail_transaksi_produksi` (`id_detail_transaksiproduksi`, `id_transaksiproduksi`, `id_detailsuplai`, `jumlah_pengurangan`, `barang_rejectproduksi`) VALUES ('100', '60', '23', '1000', '20');
INSERT INTO `detail_transaksi_produksi` (`id_detail_transaksiproduksi`, `id_transaksiproduksi`, `id_detailsuplai`, `jumlah_pengurangan`, `barang_rejectproduksi`) VALUES ('101', '60', '38', '1000', '20');
INSERT INTO `detail_transaksi_produksi` (`id_detail_transaksiproduksi`, `id_transaksiproduksi`, `id_detailsuplai`, `jumlah_pengurangan`, `barang_rejectproduksi`) VALUES ('104', '63', '23', '1663', '0');


#
# TABLE STRUCTURE FOR: driver
#

DROP TABLE IF EXISTS `driver`;

CREATE TABLE `driver` (
  `id_driver` int(50) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(50) NOT NULL,
  `shift` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  PRIMARY KEY (`id_driver`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('7', 'Akbar Haris', 'shift1', '087865516211');
INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('8', 'Hanif Jauhari', 'shift1', '08786512234');
INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('9', 'Lutfi Fajar', 'shift3', '081869122450');
INSERT INTO `driver` (`id_driver`, `nama_staff`, `shift`, `nohp`) VALUES ('10', 'Dimas Pranata', 'shift1', '08786511');


#
# TABLE STRUCTURE FOR: hasil_produksi
#

DROP TABLE IF EXISTS `hasil_produksi`;

CREATE TABLE `hasil_produksi` (
  `id_hasilproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `id` int(50) NOT NULL,
  `shift` varchar(255) NOT NULL,
  `jumlah_produksi` int(255) NOT NULL,
  `produksi_gagal` int(50) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_hasilproduksi`),
  KEY `id_pegawai_idxfk` (`id`),
  CONSTRAINT `hasil_produksi_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=latin1;

INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('160', '34', 'shift1', '88128', '0', '2020-01-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('165', '34', 'shift1', '75035', '0', '2020-02-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('166', '34', 'shift1', '56734', '0', '2020-03-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('167', '34', 'shift1', '65480', '0', '2020-04-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('168', '34', 'shift1', '59153', '0', '2020-05-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('169', '34', 'shift1', '52523', '0', '2020-06-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('170', '34', 'shift1', '63469', '0', '2020-07-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('171', '34', 'shift1', '67409', '0', '2020-08-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('172', '34', 'shift1', '65123', '0', '2020-09-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('173', '34', 'shift1', '58646', '0', '2020-10-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('174', '34', 'shift1', '64016', '0', '2020-11-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('175', '34', 'shift1', '51430', '0', '2020-12-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('176', '34', 'shift1', '57503', '0', '2021-01-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('177', '34', 'shift1', '34736', '0', '2021-02-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('178', '34', 'shift1', '54158', '0', '2021-03-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('179', '34', 'shift1', '46132', '0', '2021-04-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('180', '34', 'shift1', '49184', '0', '2021-05-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('181', '34', 'shift1', '52700', '0', '2021-06-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('182', '34', 'shift1', '55665', '0', '2021-07-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('183', '34', 'shift1', '42494', '0', '2021-08-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('184', '34', 'shift1', '58335', '0', '2021-09-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('185', '34', 'shift1', '31850', '0', '2021-10-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('186', '34', 'shift1', '59245', '0', '2021-11-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('187', '34', 'shift1', '55789', '0', '2021-12-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('190', '34', 'shift1', '63500', '0', '2018-01-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('191', '34', 'shift1', '43700', '0', '2018-02-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('192', '34', 'shift1', '36749', '0', '2018-03-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('193', '34', 'shift1', '52300', '0', '2018-04-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('194', '34', 'shift1', '71850', '0', '2018-05-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('195', '34', 'shift1', '84960', '0', '2018-06-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('196', '34', 'shift1', '77600', '0', '2018-07-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('197', '34', 'shift1', '68400', '0', '2018-08-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('198', '34', 'shift1', '54253', '0', '2018-10-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('199', '34', 'shift1', '44230', '0', '2018-11-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('200', '34', 'shift1', '67250', '0', '2018-12-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('201', '34', 'shift1', '57050', '0', '2019-01-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('202', '34', 'shift1', '41450', '0', '2019-02-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('203', '34', 'shift1', '64250', '0', '2019-03-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('204', '34', 'shift1', '81570', '0', '2019-04-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('205', '34', 'shift1', '45150', '0', '2019-05-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('206', '34', 'shift1', '57600', '0', '2019-06-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('207', '34', 'shift1', '38500', '0', '2019-07-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('208', '34', 'shift1', '51290', '0', '2019-08-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('209', '34', 'shift1', '79441', '0', '2019-09-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('210', '34', 'shift1', '55800', '0', '2019-10-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('211', '34', 'shift1', '76300', '0', '2019-11-01');
INSERT INTO `hasil_produksi` (`id_hasilproduksi`, `id`, `shift`, `jumlah_produksi`, `produksi_gagal`, `tanggal`) VALUES ('212', '34', 'shift1', '85730', '0', '2019-12-01');


#
# TABLE STRUCTURE FOR: notifikasi
#

DROP TABLE IF EXISTS `notifikasi`;

CREATE TABLE `notifikasi` (
  `id_notifikasi` int(11) NOT NULL AUTO_INCREMENT,
  `receiver` varchar(100) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `dibuat_pada` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `read_status` enum('delivery','seen') NOT NULL,
  PRIMARY KEY (`id_notifikasi`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4;

INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('1', 'admin', 'Produksi Baru', 'Pengolahan dibagian produksi', '', '2021-06-05 14:45:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('2', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 25', 'http://localhost/ta-inventory-hav/produksiclient', '2021-06-05 16:35:27', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('3', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 12', 'http://localhost/ta-inventory-hav-v1.1.0/produksiclient', '2021-06-05 17:02:17', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('4', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total asd', 'http://localhost/ta-inventory-hav-v1.1.0/produksiclient', '2021-06-05 17:02:17', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('5', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 12', 'http://localhost/ta-inventory-hav-v1.1.0/produksiclient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('6', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 10', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('7', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 100', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('8', 'admin', 'Tambah Barang Baru', 'Telah dibuat produksi baru dengan total 20', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('9', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 20', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('10', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-06 14:20:57', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('11', 'admin', 'Tambah Barang Baru', 'Telah dibuat  A baru dengan total 1', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('12', 'admin', 'Tambah Barang Baru', 'Telah dibuat  T baru dengan total 2', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('13', 'admin', 'Tambah Barang Baru', 'Telah dibuat  H baru dengan total 1', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('14', 'admin', 'Tambah Produksi Baru', 'Telah dibuat produksi baru dengan total 100', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('15', 'admin', 'Tambah Produksi Baru', 'Telah data produksi baru dengan total produksi ', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('16', 'admin', 'Tambah Produksi Baru', 'Telah data produksi baru dengan total produksi ', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('17', 'admin', 'Tambah Produksi Baru', 'Telah data produksi baru dengan total produksi ', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('18', 'admin', 'Tambah Barang Baru', 'Telah dibuat  H baru dengan total s', 'http://localhost:8080/dummyTAnew/ProduksiClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('19', 'admin', 'Tambah Produksi Baru', 'Telah dibuat  1 baru dengan total z', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('20', 'admin', 'Tambah Produksi Baru', 'Telah dibuat  1 baru dengan total xxxx', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('21', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 1', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('22', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 1', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-07 00:47:58', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('23', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Produksi   baru dengan total ', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:57:05', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('24', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  1Oleh Staff Haris123124Shift shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-07 00:57:05', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('25', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  10Oleh Staff HarisShift shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('26', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Akbar HarisDengan Nomor Kendaraan N9023AAB', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('27', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver awDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('28', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan N99293NA', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('29', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P929NX', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('30', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver MantapDengan Nomor Kendaraan zxczxczxc', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('31', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan N99293NAProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-08 00:03:38', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('32', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Staff Soleh shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('33', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('34', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('35', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Tutup Botol baru dengan total 10', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('36', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Driver AyasDengan Nomor Kendaraan N999XP', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('37', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Driver Ayas dengan Nomor Kendaraan N999XPProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('38', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  1000Oleh Staff Haris shift2', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('39', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Akbar Haris N shift2', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('40', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Avdio shift1', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('41', 'admin', 'Tambah Barang Baru', 'Telah dibuat  isolasi besar baru dengan total 20', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('42', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Isolasi besar baru dengan total 1000', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('43', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Tutup Botol baru dengan total 500', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('44', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Isolasi besar baru dengan total 200', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('45', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('46', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('47', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver dhioDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('48', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver dhio dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/dummyTAnew/DetailClient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('49', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Manysur shift2', 'http://localhost:8080/dummyTAnew/produksiclient', '2021-06-10 00:16:00', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('50', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:17:35', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('51', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:17:35', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('52', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 300', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-10 00:25:47', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('53', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('54', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 100', 'http://localhost:8080/dummyTAnew/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('55', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('56', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff zaman shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('57', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  SurabayaNama Driver Roy dengan Nomor Kendaraan L98128NProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('58', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver xxxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('59', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver xxxx dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('60', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver xxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('61', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('62', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 110', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('63', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris2e12ewr shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('64', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Haris shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('65', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Rifaldi shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('66', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  75Oleh Staff Dwi shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('67', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Lukman shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('68', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Bocil shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('69', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Kardus baru dengan total 100', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('70', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Isolasi baru dengan total 10', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('71', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Azmat shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-25 13:21:56', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('72', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver LALADengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('73', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('74', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('75', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('76', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff zaman12344 shift3', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 10:54:52', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('77', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Testing1 shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 11:26:47', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('78', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Botol baru dengan total 100', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-27 11:26:47', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('79', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Testing Staff PengirimanDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('80', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('81', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('82', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Testing Staff PengirimanDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('83', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-27 18:21:21', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('84', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('85', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('86', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('87', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('88', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('89', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Haris dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('90', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff Staff Produksi shift1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('91', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Test Gudangg baru dengan total 5000', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('92', 'admin', 'Tambah Barang Baru', 'Telah dibuat  Test Gudangg baru dengan total 5000', 'http://localhost:8080/FinalTA/BarangClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('93', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver Testing Staff PengirimanDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('94', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver AkbarDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('95', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Testing Staff Pengiriman dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('96', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Akbarxxxx dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('97', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver x1Dengan Nomor Kendaraan x1', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('98', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver x2Dengan Nomor Kendaraan x2', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('99', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver x3Dengan Nomor Kendaraan x3', 'http://localhost:8080/FinalTA/produksiclient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('100', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x1Nama Driver x1 dengan Nomor Kendaraan x1Proses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('101', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x2Nama Driver x2 dengan Nomor Kendaraan x2Proses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('102', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x3Nama Driver x3 dengan Nomor Kendaraan x3Proses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('103', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  x3Nama Driver x3 dengan Nomor Kendaraan x3Proses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-06-30 12:57:06', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('104', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Nama Driver HarisxxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('105', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver xxxxxxxxxxxxDengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTA/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('106', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver Harisxxx dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTA/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('107', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver xxxxxxxxxxxx dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTA/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('108', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 3Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('109', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 4Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('110', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('111', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanProses Pengiriman', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('112', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 4Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('113', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('114', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('115', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('116', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('117', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('118', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2021-07-11 12:56:55', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('119', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-11 12:59:09', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('120', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 1000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('121', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  1000Oleh Staff  shift2', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('122', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  100Oleh Staff  shift2', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('123', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 2Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('124', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 2000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('125', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 1000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('126', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 2000', 'http://localhost:8080/FinalTArev/BarangClient', '2021-07-21 14:52:16', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('127', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  3000Oleh Staff  shift1', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('128', 'admin', 'Tambah Produksi Baru', 'Penambahan Data Jumlah Produksi Hari Ini  906Oleh Staff  shift1', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('129', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 1000', 'http://localhost:8080/FinalTArev/BarangClient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('130', 'admin', 'Tambah Barang Baru', 'Telah dibuat   baru dengan total 10000', 'http://localhost:8080/FinalTArev/BarangClient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('131', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 3Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('132', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  Malang Nama Driver 4Dengan Nomor Kendaraan P2032XM', 'http://localhost:8080/FinalTArev/produksiclient', '2022-06-26 18:05:26', 'seen');
INSERT INTO `notifikasi` (`id_notifikasi`, `receiver`, `nama`, `notes`, `url`, `dibuat_pada`, `read_status`) VALUES ('133', 'admin', 'Proses Pengiriman', 'Pengiriman Barang dengan tujuan  MalangNama Driver  dengan Nomor Kendaraan P2032XMProses PengirimanSudah Terkirim', 'http://localhost:8080/FinalTArev/DetailClient', '2022-06-26 18:05:26', 'seen');


#
# TABLE STRUCTURE FOR: pegawai
#

DROP TABLE IF EXISTS `pegawai`;

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `kode_unik` varchar(10) NOT NULL,
  `level` enum('admin','Staff Produksi','Staff Pengiriman','Staff Gudang') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('32', 'Staf Gudang Perusahaan', 'gudang', '123', 'VV4HMZ', 'Staff Gudang');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('34', 'Admin Perusahaan', 'Admin', 'admin123', 'JVC4CE', 'admin');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('35', 'Staf Produksi Perusahaan', 'Produksi', '1234', 'AJHHNE', 'Staff Produksi');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('36', 'Staf Pengiriman Perusahaan', 'pengiriman', '1234', 'IOEJ3X', 'Staff Pengiriman');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('38', 'Avdio Bayu', 'Avdio', '1234', 'N4SVHV', 'Staff Produksi');
INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`, `kode_unik`, `level`) VALUES ('41', 'haris 1', '1234', '1234', 'M8RH20', 'Staff Produksi');


#
# TABLE STRUCTURE FOR: pengiriman
#

DROP TABLE IF EXISTS `pengiriman`;

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(255) NOT NULL AUTO_INCREMENT,
  `id_driver` int(50) NOT NULL,
  `nomorhp` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `jenis_kendaraan` varchar(255) NOT NULL,
  `nomor_kendaraan` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti_surat` varchar(50) NOT NULL,
  `status_pengiriman` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  PRIMARY KEY (`id_pengiriman`),
  KEY `id_driver_idxfk` (`id_driver`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;

INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('109', '3', '0256123', 'Malang', '23', 'Pickup', 'P2032XM', '2021-07-15', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('114', '3', '0256123', 'Malang', '1000', 'Pickup', 'P2032XM', '2021-07-22', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('115', '4', '0256123', 'Malang', '2000', 'Pickup', 'P2032XM', '2021-07-22', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('116', '3', '0256123', 'Malang', '23', 'Pickup', 'P2032XM', '2021-07-22', '', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `id_driver`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `bukti_surat`, `status_pengiriman`) VALUES ('117', '4', '0256123', 'Malang', '23', 'Pickup', 'P2032XM', '2021-07-24', '1626856967.png', 'Proses Pengiriman');


#
# TABLE STRUCTURE FOR: peramalan
#

DROP TABLE IF EXISTS `peramalan`;

CREATE TABLE `peramalan` (
  `id_peramalan` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL COMMENT 'relasi dengan id pada tabel pegawai',
  `tanggal_awal` varchar(15) NOT NULL,
  `tanggal_akhir` varchar(15) NOT NULL,
  `jenis_pemulusan` enum('keseluruhan','sebagian') NOT NULL,
  `nilai_pemulusan` float DEFAULT NULL,
  `perhitungan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `pengujian` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`pengujian`)),
  `tanggal_peramalan` timestamp NOT NULL DEFAULT current_timestamp(),
  `status_pengajuan` enum('pengajuan','diterima','ditolak') NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_peramalan`),
  KEY `id_pegawai` (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: transaksi_produksi
#

DROP TABLE IF EXISTS `transaksi_produksi`;

CREATE TABLE `transaksi_produksi` (
  `id_transaksiproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_hasilproduksi` int(50) NOT NULL,
  `id` int(50) NOT NULL,
  `tanggal` date NOT NULL,
  `shift` varchar(50) NOT NULL,
  PRIMARY KEY (`id_transaksiproduksi`),
  KEY `id_produk_idxfk` (`id_hasilproduksi`),
  KEY `id_pegawai_idxfk2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

INSERT INTO `transaksi_produksi` (`id_transaksiproduksi`, `id_hasilproduksi`, `id`, `tanggal`, `shift`) VALUES ('63', '129', '41', '2022-01-01', 'shift1');
INSERT INTO `transaksi_produksi` (`id_transaksiproduksi`, `id_hasilproduksi`, `id`, `tanggal`, `shift`) VALUES ('64', '158', '32', '2022-06-27', 'shift1');


